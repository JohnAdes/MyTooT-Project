import 'package:toot/Components/card_content.dart';
import 'package:toot/Components/custom_appbar.dart';
import 'package:toot/Components/reusable_card.dart';
import 'package:toot/HomeOrderAccount/Home/UI/Stores/stores.dart';
import 'package:toot/HomeOrderAccount/Home/UI/custom_delivery.dart';
import 'package:toot/Routes/routes.dart';
import 'package:toot/Themes/colors.dart';
import 'package:toot/Themes/style.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Home();
  }
}

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  String value = 'Home';
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(126.0),
        child: CustomAppBar(
          leading: Padding(
            padding: const EdgeInsets.only(left: 20.0),
            child: Icon(
              Icons.location_on,
              color: kMainColor,
            ),
          ),
          titleWidget: DropdownButton(
            value: value,
            icon: Icon(
              Icons.keyboard_arrow_down,
              color: kMainColor,
            ),
            iconSize: 24.0,
            elevation: 16,
            style: inputTextStyle.copyWith(fontWeight: FontWeight.bold),
            underline: Container(
              height: 0,
            ),
            onChanged: (String newValue) {
              setState(() {
                value = newValue;
              });
              if (value == 'Set Location')
                Navigator.pushNamed(context, PageRoutes.locationPage);
            },
            items: <String>['Home', 'Office', 'Other', 'Set Location']
                .map<DropdownMenuItem<String>>((String address) {
              return DropdownMenuItem<String>(
                value: address,
                child: Text(
                  address,
                  overflow: TextOverflow.ellipsis,
                ),
              );
            }).toList(),
          ),
          actions: <Widget>[
            Padding(
              padding: const EdgeInsets.only(right: 6.0),
              child: IconButton(
                icon: ImageIcon(
                  AssetImage('images/icons/ic_cart blk.png'),
                ),
                onPressed: () =>
                    Navigator.pushNamed(context, PageRoutes.viewCart),
              ),
            ),
          ],
          hint: 'Search item or store',
        ),
      ),
      body: Column(
        children: <Widget>[
          //               CustomSearchBar(hint: 'Search item or store'),
          Padding(
            padding: EdgeInsets.only(top: 16.0, left: 24.0),
            child: Row(
              children: <Widget>[
                Text(
                  "Got Delivered",
                  style: Theme.of(context).textTheme.bodyText1,
                ),
                SizedBox(
                  width: 5.0,
                ),
                Text(
                  "everything you need",
                  style: Theme.of(context)
                      .textTheme
                      .bodyText1
                      .copyWith(fontWeight: FontWeight.normal),
                ),
              ],
            ),
          ),
          buildGrid(),
        ],
      ),
    );
  }

  Expanded buildGrid() {
    return Expanded(
      child: Container(
        margin: EdgeInsets.all(20.0),
        child: GridView.count(
          crossAxisCount: 2,
          crossAxisSpacing: 20.0,
          mainAxisSpacing: 20.0,
          controller: ScrollController(keepScrollOffset: false),
          shrinkWrap: true,
          scrollDirection: Axis.vertical,
          children: <Widget>[
            ReusableCard(
              cardChild: CardContent(
                image:
                    AssetImage('images/maincategory/vegetables_fruitsact.png'),
                text: 'GROCERIES',
              ),
              onPress: () => Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => StoresPage('Groceries')),
              ),
            ),
            ReusableCard(
              cardChild: CardContent(
                image: AssetImage('images/maincategory/food_mealsact.png'),
                text: 'FOOD\n& MEALS',
              ),
              onPress: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => StoresPage('Food & Meals'))),
            ),
            ReusableCard(
              cardChild: CardContent(
                image: AssetImage('images/maincategory/meat_fishact.png'),
                text: 'SPECIAL\nORDERS',
              ),
              onPress: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => StoresPage('Special Orders'))),
            ),
//            ReusableCard(
//              cardChild: CardContent(
//                image:
//                    AssetImage('images/maincategory/pharma_medicinesact.png'),
//                text: 'PHARMA\nMEDICINES',
//              ),
//              onPress: () => Navigator.push(
//                  context,
//                  MaterialPageRoute(
//                      builder: (context) => StoresPage('Pharma Medicines'))),
//            ),
//            ReusableCard(
//              cardChild: CardContent(
//                image: AssetImage('images/maincategory/pet_suppliesact.png'),
//                text: 'PET\nSUPPLIES',
//              ),
//              onPress: () => Navigator.push(
//                  context,
//                  MaterialPageRoute(
//                      builder: (context) => StoresPage('Pet Supplies'))),
//            ),
            ReusableCard(
              cardChild: CardContent(
                image: AssetImage('images/maincategory/custom_deliveryact.png'),
                text: 'CUSTOM\nDELIVERY',
              ),
              onPress: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>
                          CustomDeliveryPage('Custom Delivery'))),
            ),
          ],
        ),
      ),
    );
  }
}

import 'package:toot/Components/custom_appbar.dart';
import 'package:toot/Components/search_bar.dart';
import 'package:toot/Routes/routes.dart';
import 'package:toot/Themes/colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:grouped_buttons/grouped_buttons.dart';
import 'package:toot/Themes/style.dart';

List<String> list = ['1 kg', '500 g', '250 g'];

class ItemsPage extends StatefulWidget {
  @override
  _ItemsPageState createState() => _ItemsPageState();
}

class _ItemsPageState extends State<ItemsPage> {
  int itemCount = 0;
  final List<Tab> tabs = <Tab>[
    Tab(text: 'BEVERAGES'),
    Tab(text: 'GRAINS & RICE'),
    Tab(text: 'FLOUR'),
    Tab(text: 'CANNED GOODS'),
    Tab(text: 'OILS'),
    Tab(text: 'SPICES & SEASONING'),
  ];

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: tabs.length,
      child: Scaffold(
        appBar: PreferredSize(
          preferredSize: Size.fromHeight(186.0),
          child: CustomAppBar(
            titleWidget: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text('Silver Leaf Vegetables',
                      style: Theme.of(context)
                          .textTheme
                          .bodyText1
                          .copyWith(color: kMainTextColor)),
                  SizedBox(
                    height: 10.0,
                  ),
                  Row(
                    children: <Widget>[
                      Icon(
                        Icons.location_on,
                        color: kIconColor,
                        size: 10,
                      ),
                      SizedBox(width: 10.0),
                      Text('6.4 km ',
                          style: Theme.of(context).textTheme.overline),
                      Text('|', style: Theme.of(context).textTheme.overline),
                      Text(' Union Market',
                          style: Theme.of(context).textTheme.overline),
                      Spacer(),
                      Icon(
                        Icons.access_time,
                        color: kIconColor,
                        size: 10,
                      ),
                      SizedBox(width: 10.0),
                      Text('20 MINS',
                          style: Theme.of(context).textTheme.overline),
                      SizedBox(width: 20.0),
                    ],
                  ),
                ],
              ),
            ),
            bottom: PreferredSize(
              preferredSize: Size.fromHeight(0.0),
              child: Column(
                children: <Widget>[
                  CustomSearchBar(hint: 'Search item or store'),
                  TabBar(
                    tabs: tabs,
                    isScrollable: true,
                    labelColor: kMainColor,
                    unselectedLabelColor: kLightTextColor,
                    indicatorPadding: EdgeInsets.symmetric(horizontal: 24.0),
                  ),
                  Divider(
                    color: kCardBackgroundColor,
                    thickness: 8.0,
                  )
                ],
              ),
            ),
          ),
        ),
        body: TabBarView(
          children: tabs.map((Tab tab) {
            return Stack(
              children: <Widget>[
                ListView(
                  children: <Widget>[
                    Stack(
                      children: <Widget>[
                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                            Padding(
                              padding: EdgeInsets.only(
                                  left: 20.0, top: 30.0, right: 14.0),
                              child: Image.asset(
                                'images/veg/Vegetables/onion.png',
//                                scale: 2.5,
                                height: 93.3,
                                width: 93.3,
                              ),
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Text('Fresh Red Onion',
                                    style: bottomNavigationTextStyle.copyWith(
                                        fontSize: 15)),
                                SizedBox(
                                  height: 8.0,
                                ),
                                Text('\$ 3.00',
                                    style: Theme.of(context).textTheme.caption),
                                SizedBox(
                                  height: 20.0,
                                ),
                                InkWell(
                                  onTap: () {
                                    showModalBottomSheet(
                                      context: context,
                                      builder: (context) {
                                        return BottomSheetWidget();
                                      },
                                    );
                                  },
                                  child: Container(
                                    height: 30.0,
                                    padding:
                                        EdgeInsets.symmetric(horizontal: 12.0),
                                    decoration: BoxDecoration(
                                      color: kCardBackgroundColor,
                                      borderRadius: BorderRadius.circular(30.0),
                                    ),
                                    child: Row(
                                      children: <Widget>[
                                        Text(
                                          '1kg',
                                          style: Theme.of(context)
                                              .textTheme
                                              .caption,
                                        ),
                                        SizedBox(
                                          width: 8.0,
                                        ),
                                        Icon(
                                          Icons.keyboard_arrow_down,
                                          color: kMainColor,
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                        Positioned(
                          right: 20.0,
                          bottom: 14,
                          child: itemCount == 0
                              ? Container(
                                  height: 30.0,
                                  child: FlatButton(
                                    child: Text(
                                      'Add',
                                      style: Theme.of(context)
                                          .textTheme
                                          .caption
                                          .copyWith(
                                              color: kMainColor,
                                              fontWeight: FontWeight.bold),
                                    ),
                                    textTheme: ButtonTextTheme.accent,
                                    onPressed: () {
                                      setState(() {
                                        itemCount++;
                                      });
                                    },
                                  ),
                                )
                              : Container(
                                  height: 30.0,
                                  padding:
                                      EdgeInsets.symmetric(horizontal: 11.0),
                                  decoration: BoxDecoration(
                                    border: Border.all(color: kMainColor),
                                    borderRadius: BorderRadius.circular(30.0),
                                  ),
                                  child: Row(
                                    children: <Widget>[
                                      InkWell(
                                        onTap: () {
                                          setState(() {
                                            itemCount--;
                                          });
                                        },
                                        child: Icon(
                                          Icons.remove,
                                          color: kMainColor,
                                          size: 20.0,
                                          //size: 23.3,
                                        ),
                                      ),
                                      SizedBox(width: 8.0),
                                      Text(itemCount.toString(),
                                          style: Theme.of(context)
                                              .textTheme
                                              .caption),
                                      SizedBox(width: 8.0),
                                      InkWell(
                                        onTap: () {
                                          setState(() {
                                            itemCount++;
                                          });
                                        },
                                        child: Icon(
                                          Icons.add,
                                          color: kMainColor,
                                          size: 20.0,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                        ),
                      ],
                    ),
                  ],
                ),
                Align(
                  alignment: Alignment.bottomCenter,
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 20.0),
                    child: Row(
                      children: <Widget>[
                        Image.asset(
                          'images/icons/ic_cart wt.png',
                          height: 19.0,
                          width: 18.3,
                        ),
                        SizedBox(width: 20.7),
                        Text(
                          '2 items | \$ 7.50',
                          style: bottomBarTextStyle.copyWith(
                              fontSize: 15, fontWeight: FontWeight.w500),
                        ),
                        Spacer(),
                        FlatButton(
                          color: Colors.white,
                          onPressed: () =>
                              Navigator.pushNamed(context, PageRoutes.viewCart),
                          child: Text(
                            'View Cart',
                            style: Theme.of(context).textTheme.caption.copyWith(
                                color: kMainColor, fontWeight: FontWeight.bold),
                          ),
                          textTheme: ButtonTextTheme.accent,
                          disabledColor: Colors.white,
                        ),
                      ],
                    ),
                    color: kMainColor,
                    height: 60.0,
                  ),
                ),
              ],
            );
          }).toList(),
        ),
      ),
    );
  }
}

class BottomSheetWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ListView(
      children: <Widget>[
        Container(
          height: 80.7,
          color: kCardBackgroundColor,
          padding: EdgeInsets.all(10.0),
          child: ListTile(
            title: Text('Fresh Red Onions',
                style: Theme.of(context)
                    .textTheme
                    .caption
                    .copyWith(fontSize: 15, fontWeight: FontWeight.w500)),
            subtitle: Text('Vegetables',
                style:
                    Theme.of(context).textTheme.caption.copyWith(fontSize: 15)),
            trailing: FlatButton(
              color: Colors.white,
              onPressed: () {/*...*/},
              child: Text(
                'Add',
                style: Theme.of(context)
                    .textTheme
                    .caption
                    .copyWith(color: kMainColor, fontWeight: FontWeight.bold),
              ),
              textTheme: ButtonTextTheme.accent,
              disabledColor: Colors.white,
            ),
          ),
        ),
        CheckboxGroup(
          labelStyle:
              Theme.of(context).textTheme.caption.copyWith(fontSize: 16.7),
          labels: list,
        ),
      ],
    );
  }
}

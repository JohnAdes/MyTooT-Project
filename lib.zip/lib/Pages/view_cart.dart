import 'package:toot/Components/entry_field.dart';
import 'package:flutter/material.dart';
import 'package:toot/Themes/colors.dart';
import 'package:toot/Components/bottom_bar.dart';
import 'package:toot/Routes/routes.dart';

List<DropdownMenuItem<String>> listDrop = [];

void loadData() {
  listDrop = [];
  listDrop.add(DropdownMenuItem(
    child: Text('1 kg'),
    value: 'A',
  ));
  listDrop.add(DropdownMenuItem(
    child: Text('500 g'),
    value: 'B',
  ));
  listDrop.add(DropdownMenuItem(
    child: Text('250 g'),
    value: 'C',
  ));
}

class ViewCart extends StatefulWidget {
  @override
  _ViewCartState createState() => _ViewCartState();
}

class _ViewCartState extends State<ViewCart> {
  int _itemCount = 0;
  int _itemCount1 = 0;
  int _itemCount2 = 0;

  @override
  Widget build(BuildContext context) {
    loadData();
    return Scaffold(
      appBar: AppBar(
        title:
            Text('Confirm Order', style: Theme.of(context).textTheme.bodyText1),
      ),
      body: Stack(
        children: <Widget>[
          ListView(
            children: <Widget>[
              Container(
                padding: EdgeInsets.all(20.0),
                color: kCardBackgroundColor,
                child: Text('SILVER LEAF VEGETABLES',
                    style: Theme.of(context).textTheme.headline6.copyWith(
                        color: Color(0xff616161), letterSpacing: 0.67)),
              ),
              cartOrderItemListTile(
                  context,
                  'Fresh Red Onion',
                  '3.00',
                  _itemCount,
                  () => setState(() => _itemCount--),
                  () => setState(() => _itemCount++)),
              Divider(
                color: kCardBackgroundColor,
                thickness: 1.0,
              ),
              cartOrderItemListTile(
                  context,
                  'Fresh Cauliflower',
                  '4.50',
                  _itemCount1,
                  () => setState(() => _itemCount1--),
                  () => setState(() => _itemCount1++)),
              Divider(
                color: kCardBackgroundColor,
                thickness: 1.0,
              ),
              cartOrderItemListTile(
                  context,
                  'Fresh Red Tomatoes',
                  '2.50',
                  _itemCount2,
                  () => setState(() => _itemCount2--),
                  () => setState(() => _itemCount2++)),
              Divider(
                color: kCardBackgroundColor,
                thickness: 6.7,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8.0),
                child: EntryField(
                  hint: 'Any instruction? E.g Carry package carefully',
                  image: 'images/custom/ic_instruction.png',
                  border: InputBorder.none,
                ),
              ),
              Divider(
                color: kCardBackgroundColor,
                thickness: 6.7,
              ),
              Container(
                width: double.infinity,
                padding: EdgeInsets.symmetric(vertical: 8.0, horizontal: 20.0),
                child: Text('PAYMENT INFO',
                    style: Theme.of(context)
                        .textTheme
                        .headline6
                        .copyWith(color: kDisabledColor)),
                color: Colors.white,
              ),
              Container(
                color: Colors.white,
                padding: EdgeInsets.symmetric(vertical: 4.0, horizontal: 20.0),
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Text(
                        'Sub Total',
                        style: Theme.of(context).textTheme.caption,
                      ),
                      Text(
                        '\$ 10.00',
                        style: Theme.of(context).textTheme.caption,
                      ),
                    ]),
              ),
              Divider(
                color: kCardBackgroundColor,
                thickness: 1.0,
              ),
              Container(
                color: Colors.white,
                padding: EdgeInsets.symmetric(vertical: 4.0, horizontal: 20.0),
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Text(
                        'Service Fee',
                        style: Theme.of(context).textTheme.caption,
                      ),
                      Text(
                        '\$ 1.50',
                        style: Theme.of(context).textTheme.caption,
                      ),
                    ]),
              ),
              Divider(
                color: kCardBackgroundColor,
                thickness: 1.0,
              ),
              Container(
                color: Colors.white,
                padding: EdgeInsets.symmetric(vertical: 4.0, horizontal: 20.0),
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Text(
                        'Amount to Pay',
                        style: Theme.of(context)
                            .textTheme
                            .caption
                            .copyWith(fontWeight: FontWeight.bold),
                      ),
                      Text(
                        '\$ 11.50',
                        style: Theme.of(context).textTheme.caption,
                      ),
                    ]),
              ),
              Container(
                height: 132.0,
                color: kCardBackgroundColor,
              ),
            ],
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.end,
              children: <Widget>[
                Container(
                  color: Colors.white,
                  child: Padding(
                    padding: EdgeInsets.only(
                        left: 20.0, right: 20.0, top: 13.0, bottom: 13.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: <Widget>[
                        Row(
                          children: <Widget>[
                            Icon(
                              Icons.location_on,
                              color: Color(0xffc4c8c1),
                              size: 13.3,
                            ),
                            SizedBox(
                              width: 11.0,
                            ),
                            Text('Deliver to',
                                style: Theme.of(context)
                                    .textTheme
                                    .caption
                                    .copyWith(
                                        color: kDisabledColor,
                                        fontWeight: FontWeight.bold)),
                            Text(' HOME',
                                style: Theme.of(context)
                                    .textTheme
                                    .caption
                                    .copyWith(
                                        color: kMainColor,
                                        fontWeight: FontWeight.bold)),
                            Spacer(),
                            Text('CHANGE',
                                style: Theme.of(context)
                                    .textTheme
                                    .caption
                                    .copyWith(
                                        color: kMainColor,
                                        fontWeight: FontWeight.bold)),
                          ],
                        ),
                        SizedBox(
                          height: 13.0,
                        ),
                        Text(
                            '1024, Central Residency Hemilton Park, New York, USA',
                            style: Theme.of(context).textTheme.caption.copyWith(
                                fontSize: 11.7, color: Color(0xffb7b7b7)))
                      ],
                    ),
                  ),
                ),
                BottomBar(
                  text: "Pay \$ "
                      "11.50",
                  onTap: () => Navigator.popAndPushNamed(
                      context, PageRoutes.paymentMethod),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget cartOrderItemListTile(
    BuildContext context,
    String title,
    String price,
    int itemCount,
    Function onPressedMinus,
    Function onPressedPlus,
  ) {
    String selected;
    return Column(
      children: <Widget>[
        Padding(
            padding: const EdgeInsets.only(left: 7.0, top: 13.3),
            child: ListTile(
              // contentPadding: EdgeInsets.symmetric(horizontal: 10.0, vertical: 8.0),
              title: Text(
                title,
                style: Theme.of(context)
                    .textTheme
                    .subtitle2
                    .copyWith(color: kMainTextColor),
              ),
              subtitle: Padding(
                padding: const EdgeInsets.only(top: 15.0, bottom: 14.2),
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Container(
                        height: 30.0,
                        padding: EdgeInsets.symmetric(horizontal: 12.0),
                        decoration: BoxDecoration(
                          color: kCardBackgroundColor,
                          borderRadius: BorderRadius.circular(30.0),
                        ),
                        child: DropdownButtonHideUnderline(
                          child: DropdownButton(
                              icon: Icon(
                                Icons.keyboard_arrow_down,
                                size: 16.7,
                              ),
                              iconEnabledColor: Colors.green,
                              value: selected,
                              items: listDrop,
                              hint: Text(
                                '1 kg',
                                style: Theme.of(context).textTheme.caption,
                              ),
                              onChanged: (value) {
                                setState(() {
                                  selected = value;
                                });
                              }),
                        ),
                      ),
                      Spacer(),
                      Container(
                        height: 30.0,
                        //width: 76.7,
                        padding: EdgeInsets.symmetric(horizontal: 12.0),
                        decoration: BoxDecoration(
                          border: Border.all(color: kMainColor),
                          borderRadius: BorderRadius.circular(30.0),
                        ),
                        child: Row(
                          children: <Widget>[
                            InkWell(
                              onTap: onPressedMinus,
                              child: Icon(
                                Icons.remove,
                                color: kMainColor,
                                size: 20.0,
                                //size: 23.3,
                              ),
                            ),
                            SizedBox(width: 8.0),
                            Text(itemCount.toString(),
                                style: Theme.of(context).textTheme.caption),
                            SizedBox(width: 8.0),
                            InkWell(
                              onTap: onPressedPlus,
                              child: Icon(
                                Icons.add,
                                color: kMainColor,
                                size: 20.0,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ]),
              ),
            ))
      ],
    );
  }
}
